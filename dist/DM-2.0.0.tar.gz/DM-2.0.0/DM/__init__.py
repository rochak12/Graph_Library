# if you have a class inside a module
from DM.Graph import Graph

# if you have a functions inside a module
import DM.Huffman
from DM import Huffman

# if you have .py and no class nothing needed
