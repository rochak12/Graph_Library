from DM_Library.Huffman import Huffman
from DM_Library.Spanning_Tree import Spanning_Tree
from DM_Library.Graph import Graph