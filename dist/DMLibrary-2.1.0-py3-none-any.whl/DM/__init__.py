# if you have a class inside a module
from DMLibrary.Graph import Graph

# if you have a functions inside a module
import DMLibrary.Huffman
from DMLibrary import Huffman

# if you have .py and no class nothing needed
